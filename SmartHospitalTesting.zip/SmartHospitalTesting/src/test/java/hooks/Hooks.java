package hooks;

import driver.Driver;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	
	@Before
	public void setup() {
	    new Driver();
	}
	
	@After
	public void tearDown() {
		Driver.quitDriver();
	}
	

}
